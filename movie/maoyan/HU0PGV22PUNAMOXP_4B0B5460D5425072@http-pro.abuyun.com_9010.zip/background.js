
            var config = {
                mode: "fixed_servers",
                rules: {
                    singleProxy: {
                        scheme: "https",
                        host: "http-pro.abuyun.com",
                        port: parseInt(9010)
                    },
                    bypassList: ["foobar.com"]
                }
              };

            chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

            function callbackFn(details) {
                return {
                    authCredentials: {
                        username: "HU0PGV22PUNAMOXP",
                        password: "4B0B5460D5425072"
                    }
                };
            }

            chrome.webRequest.onAuthRequired.addListener(
                callbackFn,
                {urls: ["<all_urls>"]},
                ['blocking']
            );
            